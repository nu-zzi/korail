
/* 서비스예매 이미지 돌아가기 */
$(function () {
    $(".location").flip({
        axis: "y", //중심축
        reverse: true, //역,전환
        trigger: "hover" //마우스올렸을때
    });
});

/* 광고배너1 자동넘김 */

$(function(){
    var banner=$('.cont1_R_1>ul>li');
    var button1=$('arrowbox>a.next');
    var button2=$('arrowbox>a.prev');
    var current=0;
    var setIntervalId00;
    var p=$('.number>p');

    timer(); //사용자 지정함수
    function timer(){
        setIntervalId00=setInterval(function(){
            var prev=banner.eq(current);
            var pn=p.eq(current);

            move(prev,0, '-100%');
            pn.removeClass('bl');

            current++;
            if(current==banner.size()){current=0;}

            var next=banner.eq(current);
            var pnn=p.eq(current);
            move(next, '100%', 0);
            pnn.addClass('bl');
        },2000)
    }

    function move(tg, start, end){
        tg.css('left', start).stop().animate({left:end},{duration:500,ease:'easeOutCubic'});
    }

    $('.cont1_R_1').on({mouseover:function(){
        clearInterval(setIntervalId00);
    },mouseout:function(){
        timer();
    }

});

    button1.click(function(){
        var prev=banner.eq(current);
        var pn=p.eq(current);

        move(prev, 0, '-100%');
        pn.removeClass('bl');

        current++;

        if(current==banner.size()){current=0;}
        var next=banner.eq(current);
        var pnn=p.eq(current);
        move(next, '100%', 0);
        pnn.addClass('bl');
    });


    button2.click(function(){
        var prev=banner.eq(current);
        var pn=p.eq(current);

        move(prev, 0, '100%');
        pn.removeClass('bl');

        current--;

        if(current==banner.size()){current=0;}
        var next=banner.eq(current);
        var pnn=p.eq(current);
        move(next, '-100%', 0);
        pnn.addClass('bl');
    });

});